CREATE TABLE `main`.`heroes` (  
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(64) NOT NULL,
  `sub_title` VARCHAR(64),
  `strength` VARCHAR(64) NOT NULL,
  `weakness` VARCHAR(64),
  `hero_call` VARCHAR(256),
  PRIMARY KEY (`id`)
) CHARSET=utf8 COLLATE=utf8_unicode_ci;
