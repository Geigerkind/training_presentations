INSERT main.heroes (`name`, `sub_title`, `strength`, `weakness`, `hero_call`) VALUES
("Meerjungfraumann", "Pensionär", "Blubber", "Gedächtnis", "Meerjungfraumann und Blaubarschbube vereint!"),
("Blaubarschbube", "Pensionär", "Treue", "Meerjungfraumann", "Meerjungfraumann und Blaubarschbube vereint!"),
("Spider-Man", "von einer Spinne gebissen", "Spinnenweben", NULL, NULL),
("Aqua-Man", "Meerjungfraumann abklatsch", "Wasser", NULL, NULL),
("Aqua-Lad", "Blaubarschbube abklatsch", "Keine Ahnung", "Aqua-Man", NULL),
("Bat-Man", "I AM BATMAN", "Geld", "Joker", "NANANANANANANNANANANNA BATMAN"),
("Super-Man", NULL, "Laseraugen und so", "Kryptonit", NULL),
("Wolverine", NULL, "Unsterblichkeit", "Magnet einer Autopresse", NULL),
("Linus Torvalds", "Linux und Git Erfinder", "Kann C", "Windows", "NANANANANNANANA LINUS TORVALDS"),
("Richard Stallman", "GNU's Not Unix", "Missionieren", "Proprietäre Software", NULL),
("Spider-Pig", "The Simpsons", "An decken laufen", "McDonalds", "Spider-Pig, Spider-Pig, Does whatever a Spider-Pig does..."),
("Ash Ketchum", "Nicht zu verwechseln mit Ketchup", "Altert nicht", "Naiv", "Pokemon, gotta catch em all...");
